# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main',
                     'say-hello = gendiff.scripts.hello:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'gendiff',
    'long_description': None,
    'author': 'qamaz',
    'author_email': 'solgrini@yandex.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
